var UserInput = require('../models/userInput');

exports.insertInput = function (req, res) {
    var userData=req.body;
    var email=userData.email;
    var arrival_date=userData.arrival_date;
    var departure_date=userData.departure_date;
    var destination_country=userData.destination_country;
    var destination_city=userData.destination_city;
    var interests=userData.interests;

    console.log(email);

    if(userData==null){
        res.status(403).send("No data sent!");
    }
    try{
        var userInput=new UserInput({
            email:email,
            arrival_date:arrival_date,
            departure_date:departure_date,
            destination_country:destination_country,
            destination_city:destination_city,
            interests:interests
        });

        console.log(userInput);
        userInput.save(function(err,result){});
        res.render('finish', { title: 'Express' });
    }catch (e) {
        res.status(500).send('error ' + e);
    }
}
