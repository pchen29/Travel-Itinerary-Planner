var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var userInput = new Schema(
    {
        email:{type:String},
        arrival_date: {type: Date},
        departure_date: {type: Date},
        destination_country: {type: String},
        destination_city: {type: String},
        interests: {type: String}
    }, {collection: 'userInput'}
);

userInput.set('toObject', { getters: true, virtuals: true });

var userInputModel = mongoose.model('userInput', userInput);

module.exports = userInputModel;